adc 4
ldc 0
div